package capstone.onlineforum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineforumApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineforumApplication.class, args);
	}

}
